const express = require('express')
const app = express()

//npm install method-override 입력해서 라이브러리 설치 후 셋팅
const methodOverride = require('method-override')
app.use(methodOverride('_method')) 

//ObjectId()를 쓰려면 아래코드 추가
const { ObjectId } = require('mongodb') 

//글쓰기 기능 구현
//원래 유저가 데이터를 보내면(POST 요청) 그걸 꺼내쓰는 코드가 좀 귀찮게 되어있는데
//그걸 요청.body로 쉽게 꺼내쓸 수 있게 도와주는 코드
app.use(express.json())
app.use(express.urlencoded({extended:true})) 


//서버파일에 app.use 문법으로 public 폴더를 등록 
//public 폴더에 보통 css, 이미지, js 파일 넣어놓음
app.use(express.static(__dirname + '/public'));

// ---------ejs 라이브러리 셋팅----------------
//ejs파일 만들어야하는데 view 폴더 안에 만드는게 국룰임!
// ejs를 이용해서 html 파일안에 데이터들을 막 꽂아줄 수 있습니다.
app.set('view engine', 'ejs')

// ---------mongoDB 라이브러리 셋팅----------------
const { MongoClient } = require('mongodb')

let db
const url = 'mongodb+srv://admin:qwer1234@cluster0.c21potr.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
new MongoClient(url).connect().then((client)=>{
  console.log('DB연결성공')
  db = client.db('forum');
  app.listen(8080, () => {
    console.log('http://localhost:8080 에서 서버 실행중')
  })
}).catch((err)=>{
  console.log(err)
})
// --------------------------------------------


app.get('/', (요청, 응답) => {
  let ts = new Date()   
  응답.send(ts + typeof(ts))
}) 

//news접속 시 해당 db에 데이터를 넣을 수 있는 방법
app.get('/news', (요청, 응답) => {
  db.collection('post').insertOne({title:'어쩌구'})
  // 응답.send('반갑다dsad')
}) 

//about 접속 시 html 파일 접속
app.get('/about', function(요청, 응답) {
  응답.sendFile(__dirname + '/index.html')
})

app.get('/list', async (요청,응답) => {
  //암기!!! 컬렉션의 모든 document 출력하는 방법
  let result = await db.collection('post').find().toArray()
  console.log(result)
  
  //유저에게 ejs파일 보내는법
  응답.render('list.ejs', {글목록 : result})
})


//time 접속시 ejs로 웹페이지를 만들어 서버시간을 보여주고 싶음
app.get('/time', (요청,응답) => {
  응답.render('time.ejs', {data : new Date()})
})

//글쓰기 기능 구현
//time 접속시 ejs로 웹페이지를 만들어 서버시간을 보여주고 싶음
app.get('/write', (요청,응답) => {
  응답.render('write.ejs')
})

app.post('/add', async (요청, 응답)=>{
  let data = 요청.body
  //write.ejs에서 받은 데이터를 db에 저장
  try {
    if(data.title == '') {
      응답.send('제목 입력안했음')
    } else {
      await db.collection('post').insertOne({title: data.title, content : data.content})
      응답.redirect('/list')
    }
  } catch (e) {
      console.log(e)
      응답.send('DB에러남')
    } 
})

//상세페이지
app.get('/detail/:aaaa', async (요청, 응답) => {
  console.log(요청.params)
  //DB에서 특정 document 1개 찾기
  try {
    let data = await db.collection('post').findOne({_id : new ObjectId(요청.params.aaaa)})
    if (data == null) {
      응답.status(400).send('그런 글 없음')
    } else {
      //detail.ejs에 찾은 데이터 박아주기
      응답.render('detail.ejs', {data: data})
    }
  } catch (e){
    응답.send('이상한거 넣지마라')
  }

})

//수정기능 구현하기
app.get('/edit/:id', async (요청, 응답) => {
  //console에 id 입력한거 object 자료형으로 뜸!
  console.log(요청.params)
  let result = await db.collection('post').findOne({ _id : new ObjectId(요청.params.id)})
  응답.render('edit.ejs', {result : result})
})

//edit.ejs에서 버튼누르면 DB 수정 처리
app.post('/edit', async (요청, 응답)=>{
  let data = 요청.body
  console.log(data) 
  db.collection('post').updateOne( { _id : new ObjectId(data.id) }, 
  {$set: { title : data.title, content : data.content }}) 
  응답.redirect('/list')
})

//글 삭제 기능 구현
app.delete('/delete', async (요청, 응답) => {
  console.log(요청.query)
  let result = await db.collection('post').deleteOne( { _id : new ObjectId(요청.query.docid) } )
  응답.send('삭제완료')
})

app.get('/test', (요청, 응답) => {
  응답.send()
})